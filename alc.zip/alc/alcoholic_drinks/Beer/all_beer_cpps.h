#include "IPA/all_ipa_cpps.h"
#include "Lager/all_lager_cpps.h"
#include "Stout/all_stout_cpps.h"

#include "Beer.cpp"
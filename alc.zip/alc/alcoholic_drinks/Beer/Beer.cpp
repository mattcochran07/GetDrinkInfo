#include "Beer.h"

namespace Drinks {
namespace Beer {

const float BEER_NUM_OUNCES = 12;

Beer::Beer()
{

}

Beer::~Beer()
{

}

void Beer::tellUsAboutThisBeer(std::string name)
{
    Drink::tellUsAboutThisDrink(name);
    std::cout << "This drink is a Beer.  "; 
    Drink::printNumOunces(BEER_NUM_OUNCES);
}

} //end namespace Beer
} //end namespace Drinks
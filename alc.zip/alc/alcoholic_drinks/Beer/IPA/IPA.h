#ifndef IPA_H__
#define IPA_H__

#include "../Beer.h"
#include <iostream>
#include <string>

namespace Drinks {
namespace Beer {
namespace IPA {

enum {
    IPA_TYPE_HAZY_IPA,
};

class IPA : public Beer
{
public:
IPA();
~IPA();
static void tellUsAboutThatIPA(std::string name);

private:
};

} //end namespace IPA
} //end namespace Beer
} //end namespace Drinks

#endif //IPA_H__
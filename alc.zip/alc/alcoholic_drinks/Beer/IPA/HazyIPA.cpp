#include "HazyIPA.h"

namespace Drinks {
namespace Beer {
namespace IPA {

const float ABV = 6.7;

HazyIPA::HazyIPA()
{
    _drinkType = DRINK_TYPE_HAZY_IPA;
}

HazyIPA::~HazyIPA()
{

}

void HazyIPA::tellUsAboutThatHazyIPA(std::string name)
{
    IPA::tellUsAboutThatIPA(name);
    Drink::printAlcPercentage(ABV);
    std::cout << "The Hazy IPA is horrible dont order it" << std::endl;
}

} //end namespace HazyIPA
} //end namespace Beer
} //end namespace Drinks
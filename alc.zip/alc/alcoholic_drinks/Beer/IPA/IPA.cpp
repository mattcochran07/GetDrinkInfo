#include "IPA.h"

namespace Drinks {
namespace Beer {
namespace IPA {

IPA::IPA()
{

}

IPA::~IPA()
{

}

void IPA::tellUsAboutThatIPA(std::string name)
{
    Beer::tellUsAboutThisBeer(name);
    std::cout << "More specifically this beer is an IPA." << std::endl;
    std::cout << "IPAs are known for being higher in alcohol percent and higher in hops/bitters" << std::endl;
}

} //end namespace IPA
} //end namespace Beer
} //end namespace Drinks

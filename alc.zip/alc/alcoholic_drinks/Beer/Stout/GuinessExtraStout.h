#ifndef GUINESS_EXTRA_STOUT_H__
#define GUINESS_EXTRA_STOUT_H__

#include <iostream>
#include <string>
#include "Stout.h"

namespace Drinks {
namespace Beer {
namespace Stout {

class GuinessExtraStout : public Stout
{
public:
GuinessExtraStout();
~GuinessExtraStout();
static void tellUsAboutThisGuinessExtraStout(std::string name);

private:
};

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks



#endif //GUINESS_EXTRA_STOUT_H__
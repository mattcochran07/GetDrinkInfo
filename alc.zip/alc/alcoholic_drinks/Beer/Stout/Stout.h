#ifndef STOUT_H__
#define STOUT_H__

#include <iostream>
#include <string>
#include "../Beer.h"

namespace Drinks {
namespace Beer {
namespace Stout {

enum {
    STOUT_TYPE_GUINESS_EXTRA_STOUT
};

class Stout : public Beer
{
public:
Stout();
~Stout();
static void tellUsAboutThisStout(std::string name);

private:
};

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks



#endif //STOUT_H__
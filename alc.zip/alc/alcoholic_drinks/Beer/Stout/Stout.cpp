#include "Stout.h"

namespace Drinks {
namespace Beer {
namespace Stout {

Stout::Stout()
{

}

Stout::~Stout()
{

}

void Stout::tellUsAboutThisStout(std::string name)
{
    Beer::tellUsAboutThisBeer(name);
    std::cout << "More specifically this beer is a Stout" << std::endl;
}

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks
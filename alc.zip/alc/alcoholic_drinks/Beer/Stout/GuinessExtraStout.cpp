#include "GuinessExtraStout.h"

namespace Drinks {
namespace Beer {
namespace Stout {

GuinessExtraStout::GuinessExtraStout()
{
    _drinkType = DRINK_TYPE_GUINESS_EXTRA_STOUT;
}

GuinessExtraStout::~GuinessExtraStout()
{
    
}

void GuinessExtraStout::tellUsAboutThisGuinessExtraStout(std::string name)
{
    Stout::tellUsAboutThisStout(name);
    std::cout << "Can only have a few of these bad boys in a night" << std::endl;
}

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks
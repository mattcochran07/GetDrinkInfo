#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

Lager::Lager()
{

}

Lager::~Lager()
{

}

void Lager::tellUsAboutThisLager(std::string name)
{
    Beer::tellUsAboutThisBeer(name);
    std::cout << "More specifically this Beer is a Lager.  ";
    std::cout << "Lagers are typically known for being low in bitters and very light" << std::endl;
}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#ifndef COORS_LIGHT_H__
#define COORS_LIGHT_H__

#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

class CoorsLight : public Lager
{
public:
CoorsLight();
~CoorsLight();
static void tellUsAboutThisCoorsLight(std::string name);

private:
};

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#endif //COORS_LIGHT_H__
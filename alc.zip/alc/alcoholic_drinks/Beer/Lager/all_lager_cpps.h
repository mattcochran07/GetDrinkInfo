#include "Lager.cpp"

#include "BudLight.cpp"
#include "CoorsLight.cpp"
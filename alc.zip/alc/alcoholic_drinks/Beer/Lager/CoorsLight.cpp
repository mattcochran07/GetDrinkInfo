#include "CoorsLight.h"

namespace Drinks {
namespace Beer {
namespace Lager {

const float ALC_PERCENT = 4.0;

CoorsLight::CoorsLight()
{
    _drinkType = DRINK_TYPE_COORS_LIGHT;
}

CoorsLight::~CoorsLight()
{

}

void CoorsLight::tellUsAboutThisCoorsLight(std::string name)
{
    Lager::tellUsAboutThisLager(name);
    Drink::printAlcPercentage(ALC_PERCENT);
    std::cout << "I hated on Coors Light for a long time but have come to really like it" << std::endl;
}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks
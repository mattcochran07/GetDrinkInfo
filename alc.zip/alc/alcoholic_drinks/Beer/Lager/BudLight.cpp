#include "BudLight.h"

namespace Drinks {
namespace Beer {
namespace Lager {

const float ALC_PERCENTAGE = 4.2;

BudLight::BudLight()
{
    _drinkType = DRINK_TYPE_BUD_LIGHT;
}

BudLight::~BudLight()
{

}

void BudLight::tellUsAboutThisBudLight(std::string name)
{
    Lager::tellUsAboutThisLager(name);
    Drink::printAlcPercentage(ALC_PERCENTAGE);
    std::cout << "Bud light is one of the most popular lagers today.  I love it." << std::endl;

}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks
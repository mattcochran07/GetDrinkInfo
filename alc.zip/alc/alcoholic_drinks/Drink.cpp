#include "Drink.h"

namespace Drinks {

Drink::Drink()
{
    _drinkName = "Drink";
    _drinkType = -1;
    debug = false;
    _tfValid = true;
}

Drink::~Drink()
{

}

std::string Drink::getDrinkName()
{
    return _drinkName;
}

void Drink::setDrinkName(std::string name)
{
    _drinkName = name;
}

void Drink::setDebug(bool tf)
{
    debug = tf;
}

void Drink::setValid(bool tf)
{
    _tfValid = tf;
}

bool Drink::isValid()
{
    return _tfValid;
}

int Drink::getDrinkType()
{
    return _drinkType;
}

void Drink::tellUsAboutThisDrink(std::string name)
{
    std::cout << "You have chosen the wonderful " << name << std::endl;
}

void Drink::printNumOunces(float numOz)
{
    std::cout << "The standard drink is " << numOz << " ounces." << std::endl;
}

void Drink::printAlcPercentage(float percent)
{
    std::cout << "This drink has a " << percent << "\% ABV." << std::endl;
}

} //end namespace Drinks
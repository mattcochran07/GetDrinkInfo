#include "Wine.h"

namespace Drinks {
namespace Wine {

const float WINE_NUM_OUNCES = 5;

Wine::Wine()
{

}

Wine::~Wine()
{

}

void Wine::tellUsAboutThatWine(std::string name)
{
    Drink::tellUsAboutThisDrink(name);
    std::cout << "This drink is a type of Wine.  ";
    Drink::printNumOunces(WINE_NUM_OUNCES);
}

} //end namespace Wine
} //end namespace Drinks
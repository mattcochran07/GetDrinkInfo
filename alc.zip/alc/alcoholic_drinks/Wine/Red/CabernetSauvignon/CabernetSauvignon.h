#ifndef CABERNET_SAUVIGNON_H__
#define CABERNET_SAUVIGNON_H__

#include "../Red.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace CabernetSauvignon {

class CabernetSauvignon : public Red
{
public:
CabernetSauvignon();
~CabernetSauvignon();
static void tellUsAboutThatCabernetSauvignon(std::string name);

protected:

private:
};

} //end namespace CabernetSauvignon
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //CABERNET_SAUVIGNON_H__
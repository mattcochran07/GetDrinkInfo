#ifndef MERLOT_H__
#define MERLOT_H__

#include "../Red.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace Merlot {

class Merlot : public Red
{
public:
Merlot();
~Merlot();
static void tellUsAboutThatMerlot(std::string name);

protected:

private:
};

} //end namespace Merlot
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //MERLOT_H__
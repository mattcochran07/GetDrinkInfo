#include "Red.h"

namespace Drinks {
namespace Wine {
namespace Red {

Red::Red()
{

}

Red::~Red()
{

}

void Red::tellUsAboutThatRed(std::string name)
{
    Wine::tellUsAboutThatWine(name);
    std::cout << "More specifically this wine is a Red Wine" << std::endl;
}

} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
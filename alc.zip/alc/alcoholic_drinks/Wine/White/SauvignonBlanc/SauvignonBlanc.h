#ifndef SAUVIGNON_BLANC_H__
#define SAUVIGNON_BLANC_H__

#include "../White.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace SauvignonBlanc {

class SauvignonBlanc : public White
{
public:
SauvignonBlanc();
~SauvignonBlanc();
static void tellUsAboutThatSauvignonBlanc(std::string name);

protected:

private:
};

} //end namespace SauvignonBlanc
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //SAUVIGNON_BLANC_H__
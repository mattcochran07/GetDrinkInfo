#include "PinotGrigio.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace PinotGrigio {

PinotGrigio::PinotGrigio()
{
    _drinkType = DRINK_TYPE_PINOT_GRIGIO;
}

PinotGrigio::~PinotGrigio()
{
    
}

void PinotGrigio::tellUsAboutThatPinotGrigio(std::string name)
{
    White::tellUsAboutThatWhite(name);
    std::cout << "Man this shit is as idk how mom drinks it" << std::endl;
}

} //end namespace PinotGrigio
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
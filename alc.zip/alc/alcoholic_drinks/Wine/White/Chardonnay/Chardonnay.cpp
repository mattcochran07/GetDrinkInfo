#include "Chardonnay.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace Chardonnay {

Chardonnay::Chardonnay()
{
    _drinkType = DRINK_TYPE_CHARDONNAY;
}

Chardonnay::~Chardonnay()
{

}

void Chardonnay::tellUsAboutThatChardonnay(std::string name)
{
    White::tellUsAboutThatWhite(name);
    std::cout << "cant go wrong ordering a Chardonnay out at a restraunt" << std::endl;
}

} //end namespace Chardonnay
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
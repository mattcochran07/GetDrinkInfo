#include "White.h"

namespace Drinks {
namespace Wine {
namespace White {

White::White()
{

}

White::~White()
{

}

void White::tellUsAboutThatWhite(std::string name)
{
    Wine::tellUsAboutThatWine(name);
    std::cout << "More specifically this is a white wine" << std::endl;
}

} //end namespace White
} //end namespace Wine
} //end namespace Drinks
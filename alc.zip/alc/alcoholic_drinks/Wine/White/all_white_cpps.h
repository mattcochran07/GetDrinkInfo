#include "White.cpp"

#include "Chardonnay/all_chardonnay_cpps.h"
#include "PinotGrigio/all_pinot_grigio_cpps.h"
#include "SauvignonBlanc/all_sauvignon_blanc_cpps.h"
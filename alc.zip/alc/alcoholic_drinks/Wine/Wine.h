#ifndef WINE_H__
#define WINE_H__

#include "../Drink.h"
#include <iostream>
#include <string>

namespace Drinks {
namespace Wine {

class Wine : public Drink
{
public:
Wine();
~Wine();
static void tellUsAboutThatWine(std::string name);

protected:

private:
};

}
}


#endif //WINE_H__
#include "Vodka.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

Vodka::Vodka()
{

}

Vodka::~Vodka()
{

}

void Vodka::tellUsAboutThatVodka(std::string name)
{
    Liquor::tellUsAboutThatLiquor(name);
    std::cout << "More specifically this drink is a type of vodka" << std::endl;
}

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks
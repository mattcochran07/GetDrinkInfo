#ifndef GREY_GOOSE_H__
#define GREY_GOOSE_H__

#include "Vodka.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

class GreyGoose : public Vodka
{
public:
GreyGoose();
~GreyGoose();
static void tellUsAboutThisGreyGoose(std::string name);

protected:

private:
};

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks

#endif //GREY_GOOSE_H__
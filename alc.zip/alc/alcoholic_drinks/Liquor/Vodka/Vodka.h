#ifndef VODKA_H__
#define VODKA_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

class Vodka : public Liquor
{
public:
Vodka();
~Vodka();
static void tellUsAboutThatVodka(std::string name);

protected:

private:
};

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks

#endif //VODKA_H__
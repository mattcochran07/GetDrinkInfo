#include "GreyGoose.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

GreyGoose::GreyGoose()
{
    _drinkType = DRINK_TYPE_GREY_GOOSE;
}

GreyGoose::~GreyGoose()
{

}

void GreyGoose::tellUsAboutThisGreyGoose(std::string name)
{
    Vodka::tellUsAboutThatVodka(name);
    std::cout << "The opportunity to try grey goose was thanks to meagan thanks g" << std::endl;
}

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks
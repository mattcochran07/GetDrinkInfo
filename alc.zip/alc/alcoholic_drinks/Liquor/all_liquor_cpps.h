#include "Liquor.cpp"

#include "Gin/all_gin_cpps.h"
#include "Rum/all_rum_cpps.h"
#include "Tequila/all_tequila_cpps.h"
#include "Vodka/all_vodka_cpps.h"
#include "Whiskey/all_whiskey_cpps.h"
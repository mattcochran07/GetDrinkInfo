#ifndef RUM_H__
#define RUM_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

class Rum : public Liquor
{
public:
Rum();
~Rum();
static void tellUsAboutThatRum(std::string name);

protected:

private:
};

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks

#endif //RUM_H__
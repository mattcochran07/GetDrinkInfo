#include "CaptainMorgan.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

CaptainMorgan::CaptainMorgan()
{
    _drinkType = DRINK_TYPE_CAPTAIN_MORGAN;
}

CaptainMorgan::~CaptainMorgan()
{

}

void CaptainMorgan::tellUsAboutThisCaptainMorgan(std::string name)
{
    Rum::tellUsAboutThatRum(name);
    std::cout << "Captain Morgan was Coletons ol reliable" << std::endl;
}

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks
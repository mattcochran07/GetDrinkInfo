#include "Rum.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

Rum::Rum()
{

}

Rum::~Rum()
{

}

void Rum::tellUsAboutThatRum(std::string name)
{
    Liquor::tellUsAboutThatLiquor(name);
    std::cout << "More specifically this drink is a type of Rum" << std::endl;
}

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks
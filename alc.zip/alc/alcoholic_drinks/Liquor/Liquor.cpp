#include "Liquor.h"

namespace Drinks {
namespace Liquor {

const float LIQUOR_NUM_OUNCES = 1.5;

Liquor::Liquor()
{

}

Liquor::~Liquor()
{

}

void Liquor::tellUsAboutThatLiquor(std::string name)
{
    Drink::tellUsAboutThisDrink(name);
    std::cout << "This drink is a type of Liquor.  ";
    Drink::printNumOunces(LIQUOR_NUM_OUNCES);
}

} //end namespace Liquor
} //end namespace Drinks
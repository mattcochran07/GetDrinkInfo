#include "JoseCuervo.h"

namespace Drinks {
namespace Liquor {
namespace Tequila {

JoseCuervo::JoseCuervo()
{
    _drinkType = DRINK_TYPE_JOSE_CUERVO;
}

JoseCuervo::~JoseCuervo()
{

}

void JoseCuervo::tellUsAboutThatJoseCuervo(std::string name)
{
    Tequila::tellUsAboutThatTequila(name);
    std::cout << "Jose Cuervo will always be remembered for spring break freshman year" << std::endl;
}

} //end namespace Tequila
} //end namespace Liquor
} //end namespace Drinks
#include "Tequila.h"

namespace Drinks {
namespace Liquor {
namespace Tequila {

Tequila::Tequila()
{

}

Tequila::~Tequila()
{

}

void Tequila::tellUsAboutThatTequila(std::string name)
{
    Liquor::tellUsAboutThatLiquor(name);
    std::cout << "More specifically this drink is a type of tequila" << std::endl;
}

} //end namespace Tequila
} //end namespace Liquor
} //end namespace Drinks
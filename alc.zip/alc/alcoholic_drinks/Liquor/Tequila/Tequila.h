#ifndef TEQUILA_H__
#define TEQUILA_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Tequila {

class Tequila : public Liquor
{
public:
Tequila();
~Tequila();
static void tellUsAboutThatTequila(std::string name);

protected:

private:
};

} //end namespace Tequila
} //end namespace Liquor
} //end namespace Drinks

#endif //GIN_H__
#include "Whiskey.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

Whiskey::Whiskey()
{

}

Whiskey::~Whiskey()
{

}

void Whiskey::tellUsAboutThatWhiskey(std::string name)
{
    std::cout << "Specifically this drink is a type of whiskey" << std::endl;
}

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks
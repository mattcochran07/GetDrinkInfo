#ifndef WHISKEY_H__
#define WHISKEY_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

class Whiskey : public Liquor
{
public:
Whiskey();
~Whiskey();
static void tellUsAboutThatWhiskey(std::string name);

protected:

private:
};

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks

#endif //WHISKEY_H__
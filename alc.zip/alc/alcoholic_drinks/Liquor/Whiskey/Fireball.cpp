#include "Fireball.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

Fireball::Fireball()
{
    _drinkType = DRINK_TYPE_FIREBALL;
}

Fireball::~Fireball()
{

}

void Fireball::tellUsAboutThatFireball(std::string name)
{
    Whiskey::tellUsAboutThatWhiskey(name);
    std::cout << "Fireball, love it or hate it" << std::endl;
}

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks
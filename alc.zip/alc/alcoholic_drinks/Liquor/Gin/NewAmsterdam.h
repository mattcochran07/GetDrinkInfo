#ifndef NEW_AMSTERDAM_H__
#define NEW_AMSTERDAM_H__

#include "Gin.h"

namespace Drinks {
namespace Liquor {
namespace Gin {

class NewAmsterdam : public Gin
{
public:
NewAmsterdam();
~NewAmsterdam();
static void tellUsAboutThatNewAmsterdam(std::string name);

protected:

private:
};

} //end namespace Gin
} //end namespace Liquor
} //end namespace Drinks

#endif //NEW_AMSTERDAM_H__
#ifndef GIN_H__
#define GIN_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Gin {

class Gin : public Liquor
{
public:
Gin();
~Gin();
static void tellUsAboutThatGin(std::string name);

protected:

private:
};

} //end namespace Gin
} //end namespace Liquor
} //end namespace Drinks

#endif //GIN_H__
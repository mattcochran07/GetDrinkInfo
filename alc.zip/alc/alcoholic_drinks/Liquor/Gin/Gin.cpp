#include "Gin.h"

namespace Drinks {
namespace Liquor {
namespace Gin {

Gin::Gin()
{

}

Gin::~Gin()
{

}

void Gin::tellUsAboutThatGin(std::string name)
{
    Liquor::tellUsAboutThatLiquor(name);
    std::cout << "More specifically this drink is a type of Gin" << std::endl;
}

} //end namespace Gin
} //end namespace Liquor
} //end namespace Drinks
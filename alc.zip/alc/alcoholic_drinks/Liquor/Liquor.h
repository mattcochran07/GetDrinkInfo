#ifndef LIQUOR_H__
#define LIQUOR_H__

#include "../Drink.h"

namespace Drinks {
namespace Liquor {

class Liquor : public Drink
{
public:
Liquor();
~Liquor();
static void tellUsAboutThatLiquor(std::string name);

protected:

private:
};

}
}

#endif //LIQUOR_H__
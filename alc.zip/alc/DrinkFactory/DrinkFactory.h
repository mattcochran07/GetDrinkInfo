#ifndef DRINK_FACTORY_DRINK_FACTORY_H__
#define DRINK_FACTORY_DRINK_FACTORY_H__

#include <string>
#include <iostream>
#include "../alcoholic_drinks/Drink.h"
#include "../alcoholic_drinks/all_drink_type_cpps.h"

namespace Drinks {

class DrinkFactory
{
public:
DrinkFactory();
~DrinkFactory();
Drink getDrinkType(std::string name);
void printDrinkMessage(Drink drink);

private:
};

} //end namespace Drinks

#endif //DRINK_FACTORY_DRINK_FACTORY_H__
#include "DrinkFactory.h"

namespace Drinks {

void DrinkFactory::printDrinkMessage(Drink drink)
{
    std::string name = drink.getDrinkName();
    switch (drink.getDrinkType())
    {
        case DRINK_TYPE_BUD_LIGHT:
            Beer::Lager::BudLight::tellUsAboutThisBudLight(name);
            break;

        case DRINK_TYPE_COORS_LIGHT:
            Beer::Lager::CoorsLight::tellUsAboutThisCoorsLight(name);
            break;

        case DRINK_TYPE_HAZY_IPA:
            Beer::IPA::HazyIPA::tellUsAboutThatHazyIPA(name);
            break;

        case DRINK_TYPE_GUINESS_EXTRA_STOUT:
            Beer::Stout::GuinessExtraStout::tellUsAboutThisGuinessExtraStout(name);
            break;

        case DRINK_TYPE_CABERNET_SAUVIGNON:
            Wine::Red::CabernetSauvignon::CabernetSauvignon::tellUsAboutThatCabernetSauvignon(name);
            break;

        case DRINK_TYPE_MERLOT:
            Wine::Red::Merlot::Merlot::tellUsAboutThatMerlot(name);
            break;

        case DRINK_TYPE_PINOT_NOIR:
            Wine::Red::PinotNoir::PinotNoir::tellUsAboutThatPinotNoir(name);
            break;

        case DRINK_TYPE_ROSE:
            Wine::Rose::Rose::tellUsAboutThatRose(name);
            break;

        case DRINK_TYPE_CHARDONNAY:
            Wine::White::Chardonnay::Chardonnay::tellUsAboutThatChardonnay(name);
            break;

        case DRINK_TYPE_PINOT_GRIGIO:
            Wine::White::PinotGrigio::PinotGrigio::tellUsAboutThatPinotGrigio(name);
            break;

        case DRINK_TYPE_SAUVIGNON_BLANC:
            Wine::White::SauvignonBlanc::SauvignonBlanc::tellUsAboutThatSauvignonBlanc(name);
            break;

        case DRINK_TYPE_FIREBALL:
            Liquor::Whiskey::Fireball::tellUsAboutThatFireball(name);
            break;

        case DRINK_TYPE_NEW_AMSTERDAM:
            Liquor::Gin::NewAmsterdam::tellUsAboutThatNewAmsterdam(name);
            break;

        case DRINK_TYPE_CAPTAIN_MORGAN:
            Liquor::Rum::CaptainMorgan::tellUsAboutThisCaptainMorgan(name);
            break;

        case DRINK_TYPE_JOSE_CUERVO:
            Liquor::Tequila::JoseCuervo::tellUsAboutThatJoseCuervo(name);
            break;

        case DRINK_TYPE_GREY_GOOSE:
            Liquor::Vodka::GreyGoose::tellUsAboutThisGreyGoose(name);
            break;

        default:
            break;
    }
}

} //end namespace Drinks
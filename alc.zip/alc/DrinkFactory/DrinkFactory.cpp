#include "DrinkFactory.h"

namespace Drinks {

DrinkFactory::DrinkFactory()
{

}

DrinkFactory::~DrinkFactory()
{

}

Drink DrinkFactory::getDrinkType(std::string name)
{
    Drink newDrink;
    newDrink.setValid(true);
    //namespaces are in alphabetical order
    if (name == "Hazy IPA")
    {
        newDrink = Beer::IPA::HazyIPA();
    }
    else if (name == "Bud Light")
    {
        newDrink = Beer::Lager::BudLight();
    }
    else if (name == "Coors Light")
    {
        newDrink = Beer::Lager::CoorsLight();
    }
    else if (name == "Guiness Extra Stout")
    {
        newDrink = Beer::Stout::GuinessExtraStout();
    }
    else if (name == "Beer")
    {
        newDrink = Beer::Beer();
    }
    else if (name == "New Amsterdam")
    {
        newDrink = Liquor::Gin::NewAmsterdam();
    }
    else if (name == "Captain Morgan")
    {
        newDrink = Liquor::Rum::CaptainMorgan();
    }
    else if (name == "Jose Cuervo")
    {
        newDrink = Liquor::Tequila::JoseCuervo();
    }
    else if (name == "Grey Goose")
    {
        newDrink = Liquor::Vodka::GreyGoose();
    }
    else if (name == "Fireball")
    {
        newDrink = Liquor::Whiskey::Fireball();
    }
    /*
    * Wines are only set up by type for now because if you buy wine by the brand
    * you are stupid.  All about price :)
    */
    else if (name == "Cabernet Sauvignon")
    {
        newDrink = Wine::Red::CabernetSauvignon::CabernetSauvignon();
    }
    else if (name == "Merlot")
    {
        newDrink = Wine::Red::Merlot::Merlot();
    }
    else if (name == "Pinot Noir")
    {
        newDrink = Wine::Red::PinotNoir::PinotNoir();
    }
    else if (name == "Rose")
    {
        newDrink = Wine::Rose::Rose();
    }
    else if (name == "Chardonnay")
    {
        newDrink = Wine::White::Chardonnay::Chardonnay();
    }
    else if (name == "Pinot Grigio")
    {
        newDrink = Wine::White::PinotGrigio::PinotGrigio();
    }
    else if (name == "Sauvignon Blanc")
    {
        newDrink = Wine::White::SauvignonBlanc::SauvignonBlanc();
    }
    else
    {
        std::cout << "Drink Factory getDrinkType() type " << name << " not found" << std::endl;
        newDrink.setValid(false);
    }
    return newDrink;
}

} //end namespace Drinks
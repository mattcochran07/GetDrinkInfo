#include "common_includes.h"
#include "all_cpp_files.h"

int main()
{
    std::string line;
    std::vector<std::string> lines;
    std::ifstream file;

    bool tf_debug = false;
    //read parameters file
    file.open("txt_files/run_parameters.xml");
    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            if (line.find("<debug>") != std::string::npos)
            {
                std::stringstream ss;
                std::string dbg = "<debug>";
                char num = line[dbg.size()];
                ss << num;
                int tf;
                ss >> tf;
                if (tf)
                {
                    tf_debug = true;
                }
            }
        }
    }
    file.close();

    //read drinks list file
    file.open("txt_files/drinks.txt");
    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            lines.push_back(line);
        }
    }
    file.close();

    Drinks::DrinkFactory drinkFactory;
    std::cout << "Matthews Drink Reviews:" << std::endl;
    for (int i = 0; i < lines.size(); i++)
    {
        std::string drinkName = lines[i];
        Drinks::Drink* bev = drinkFactory.getDrink(drinkName);
        bev->printDrinkReview();
    }

    return 0;
}
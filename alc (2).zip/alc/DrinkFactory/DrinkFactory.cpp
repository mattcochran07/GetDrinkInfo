#include "DrinkFactory.h"

namespace Drinks {

DrinkFactory::DrinkFactory()
{
    /*
     * Organized so that the namespaces of the drink constructor are in alphabetical order
    */

    //Beer
    drinkMap.insert(std::pair<std::string, Drink*>("Hazy IPA", new Beer::IPA::HazyIPA()));
    drinkMap.insert(std::pair<std::string, Drink*>("Bud Light", new Beer::Lager::BudLight()));
    drinkMap.insert(std::pair<std::string, Drink*>("Coors Light", new Beer::Lager::CoorsLight()));
    drinkMap.insert(std::pair<std::string, Drink*>("Corona Extra", new Beer::Lager::CoronaExtra()));
    drinkMap.insert(std::pair<std::string, Drink*>("Michelob Ultra", new Beer::Lager::MichelobUltra()));
    drinkMap.insert(std::pair<std::string, Drink*>("Guiness Extra Stout", new Beer::Stout::GuinessExtraStout()));

    //Liquor
    drinkMap.insert(std::pair<std::string, Drink*>("New Amsterdam", new Liquor::Gin::NewAmsterdam()));
    drinkMap.insert(std::pair<std::string, Drink*>("Captain Morgan", new Liquor::Rum::CaptainMorgan()));
    drinkMap.insert(std::pair<std::string, Drink*>("Jose Cuervo", new Liquor::Tequila::JoseCuervo()));
    drinkMap.insert(std::pair<std::string, Drink*>("Grey Goose", new Liquor::Vodka::GreyGoose()));
    drinkMap.insert(std::pair<std::string, Drink*>("Fireball", new Liquor::Whiskey::Fireball()));

    /*
    * Wines are only set up by type for now because if you buy wine by the brand
    * you are stupid.  All about price :)
    */
    
    //Wine
    drinkMap.insert(std::pair<std::string, Drink*>("Cabernet Sauvignon", new Wine::Red::CabernetSauvignon::CabernetSauvignon()));
    drinkMap.insert(std::pair<std::string, Drink*>("Merlot", new Wine::Red::Merlot::Merlot()));
    drinkMap.insert(std::pair<std::string, Drink*>("Pinot Noir", new Wine::Red::PinotNoir::PinotNoir()));
    drinkMap.insert(std::pair<std::string, Drink*>("Rose", new Wine::Rose::Rose()));
    drinkMap.insert(std::pair<std::string, Drink*>("Chardonnay", new Wine::White::Chardonnay::Chardonnay()));
    drinkMap.insert(std::pair<std::string, Drink*>("Pinot Grigio", new Wine::White::PinotGrigio::PinotGrigio()));
    drinkMap.insert(std::pair<std::string, Drink*>("Sauvignon Blanc", new Wine::White::SauvignonBlanc::SauvignonBlanc()));


    /*
     * All drinks must be initialized before here!
     */
    std::map<std::string,Drink*>::iterator itr;
    for (itr = drinkMap.begin(); itr != drinkMap.end(); itr++)
    {
        allDrinkNames.push_back(itr->first);
    }
}

DrinkFactory::~DrinkFactory()
{

}

Drink* DrinkFactory::getDrink(std::string name)
{
    std::map<std::string, Drink*>::iterator itr;
    for (itr = drinkMap.begin(); itr != drinkMap.end(); itr++)
    {
        if (itr->first == name)
        {
            return itr->second;
        }
    }

    //if we dont find it in the map then return an unhandled message type
    std::cout << "Didnt find " << name << " in the map, returning UnhandledDrinnk type" << std::endl;
    return (new UnhandledDrink());
}

std::vector<std::string> DrinkFactory::getAllDrinkNames()
{
    return allDrinkNames;
}

// Drink DrinkFactory::getDrinkType(std::string name)
// {
//     Drink newDrink;
//     newDrink.setValid(true);
//     //namespaces are in alphabetical order
//     if (name == "Hazy IPA")
//     {
//         newDrink = Beer::IPA::HazyIPA();
//     }
//     else if (name == "Bud Light")
//     {
//         newDrink = Beer::Lager::BudLight();
//     }
//     else if (name == "Coors Light")
//     {
//         newDrink = Beer::Lager::CoorsLight();
//     }
//     else if (name == "Guiness Extra Stout")
//     {
//         newDrink = Beer::Stout::GuinessExtraStout();
//     }
//     else if (name == "Beer")
//     {
//         newDrink = Beer::Beer();
//     }
//     else if (name == "New Amsterdam")
//     {
//         newDrink = Liquor::Gin::NewAmsterdam();
//     }
//     else if (name == "Captain Morgan")
//     {
//         newDrink = Liquor::Rum::CaptainMorgan();
//     }
//     else if (name == "Jose Cuervo")
//     {
//         newDrink = Liquor::Tequila::JoseCuervo();
//     }
//     else if (name == "Grey Goose")
//     {
//         newDrink = Liquor::Vodka::GreyGoose();
//     }
//     else if (name == "Fireball")
//     {
//         newDrink = Liquor::Whiskey::Fireball();
//     }
//     /*
//     * Wines are only set up by type for now because if you buy wine by the brand
//     * you are stupid.  All about price :)
//     */
//     else if (name == "Cabernet Sauvignon")
//     {
//         newDrink = Wine::Red::CabernetSauvignon::CabernetSauvignon();
//     }
//     else if (name == "Merlot")
//     {
//         newDrink = Wine::Red::Merlot::Merlot();
//     }
//     else if (name == "Pinot Noir")
//     {
//         newDrink = Wine::Red::PinotNoir::PinotNoir();
//     }
//     else if (name == "Rose")
//     {
//         newDrink = Wine::Rose::Rose();
//     }
//     else if (name == "Chardonnay")
//     {
//         newDrink = Wine::White::Chardonnay::Chardonnay();
//     }
//     else if (name == "Pinot Grigio")
//     {
//         newDrink = Wine::White::PinotGrigio::PinotGrigio();
//     }
//     else if (name == "Sauvignon Blanc")
//     {
//         newDrink = Wine::White::SauvignonBlanc::SauvignonBlanc();
//     }
//     else
//     {
//         std::cout << "Drink Factory getDrinkType() type " << name << " not found" << std::endl;
//         newDrink.setValid(false);
//     }
//     return newDrink;
// }

} //end namespace Drinks
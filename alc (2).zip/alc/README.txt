Built on Windows :)
Executables are in the windows_exe directory
There are 2 executables, 1 to show all the currently supported drinks and 1 to command line a certain drink

How to run:
From the alc directory pick one of the following lines to run based on which exe you want
    windows_exe\choose_drink "<Drink Name>"
    windows_exe\all_drinks

You can find a list of currently supported drinks in txt_files/current_supported_drinks.txt

To build on your own you can just execute the following:
All Drinks:
    g++ all_drinks.cpp -o windows_exe\all_drinks
Choose Drink:
    g++ choose_drink.cpp -o windows_exe\choose_drink
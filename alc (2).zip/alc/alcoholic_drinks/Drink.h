#ifndef ALCOHOLIC_DRINKS_DRINK_H__
#define ALCOHOLIC_DRINKS_DRINK_H__

#include <iostream>
#include "../DrinkFactory/all_drink_types.h"
// #include "../DrinkFactory/DrinkFactory.h"

namespace Drinks {

enum {
    DRINK_TYPE_BEER,
    DRINK_TYPE_WINE,
    DRINK_TYPE_LIQUOR,
};

class Drink
{
public:
Drink();
virtual ~Drink();
float getDrinkSize();
std::string getDrinkName();
void setDrinkName(std::string name);
void setDebug(bool tf);
void setValid(bool tf);
bool isValid();
static void tellUsAboutThisDrink(std::string name);
int getDrinkType();
static void printNumOunces(float numOz);
static void printAlcPercentage(float percent);
virtual void printDrinkReview() = 0;

protected:
std::string _drinkName;
int _drinkType;
bool debug;

private:
bool _tfValid;

friend class DrinkFactory;
};

} //end namespace Drinks

#endif //ALCOHOLIC_DRINKS_DRINK_H__
#ifndef UNHANDLED_DRINK_H__
#define UNHANDLED_DRINK_H__

#include "Drink.h"

namespace Drinks {

class UnhandledDrink : public Drink
{
public:
UnhandledDrink();
~UnhandledDrink();
void printDrinkReview();

private:
};

} //end namespace Drinks

#endif //UNHANDLED_DRINK_H__
#include "Gin.h"

namespace Drinks {
namespace Liquor {
namespace Gin {

Gin::Gin()
{

}

Gin::~Gin()
{

}

} //end namespace Gin
} //end namespace Liquor
} //end namespace Drinks
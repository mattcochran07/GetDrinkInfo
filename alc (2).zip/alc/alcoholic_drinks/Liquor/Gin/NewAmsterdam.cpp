#include "NewAmsterdam.h"

namespace Drinks {
namespace Liquor {
namespace Gin {

NewAmsterdam::NewAmsterdam()
{
    _drinkType = DRINK_TYPE_NEW_AMSTERDAM;
}

NewAmsterdam::~NewAmsterdam()
{

}

void NewAmsterdam::printDrinkReview()
{
    std::cout << "New Amsterdam treated me well in college but a lot of ppl didnt like it" << std::endl;
}

} //end namespace Gin
} //end namespace Liquor
} //end namespace Drinks
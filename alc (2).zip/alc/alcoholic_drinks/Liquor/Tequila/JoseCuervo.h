#ifndef JOSE_CUERVO_H__
#define JOSE_CUERVO_H__

#include "Tequila.h"

namespace Drinks {
namespace Liquor {
namespace Tequila {

class JoseCuervo : public Tequila
{
public:
JoseCuervo();
~JoseCuervo();
void printDrinkReview();

protected:

private:
};

} //end namespace Tequila
} //end namespace Liquor
} //end namespace Drinks

#endif //JOSE_CUERVO_H__
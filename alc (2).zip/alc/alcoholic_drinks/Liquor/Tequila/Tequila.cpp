#include "Tequila.h"

namespace Drinks {
namespace Liquor {
namespace Tequila {

Tequila::Tequila()
{

}

Tequila::~Tequila()
{

}

} //end namespace Tequila
} //end namespace Liquor
} //end namespace Drinks
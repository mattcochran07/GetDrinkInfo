#ifndef VODKA_H__
#define VODKA_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

class Vodka : public Liquor
{
public:
Vodka();
~Vodka();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks

#endif //VODKA_H__
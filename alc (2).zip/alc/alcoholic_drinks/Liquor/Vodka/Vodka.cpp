#include "Vodka.h"

namespace Drinks {
namespace Liquor {
namespace Vodka {

Vodka::Vodka()
{

}

Vodka::~Vodka()
{

}

} //end namespace Vodka
} //end namespace Liquor
} //end namespace Drinks
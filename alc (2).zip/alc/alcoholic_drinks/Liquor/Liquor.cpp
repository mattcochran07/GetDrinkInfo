#include "Liquor.h"

namespace Drinks {
namespace Liquor {

const float LIQUOR_NUM_OUNCES = 1.5;

Liquor::Liquor()
{

}

Liquor::~Liquor()
{

}

} //end namespace Liquor
} //end namespace Drinks
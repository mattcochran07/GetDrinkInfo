#ifndef FIREBALL_H__
#define FIREBALL_H__

#include "Whiskey.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

class Fireball : public Whiskey
{
public:
Fireball();
~Fireball();
void printDrinkReview();

protected:

private:
};

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks

#endif // FIREBALL_H__
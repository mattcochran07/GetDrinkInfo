#include "Whiskey.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

Whiskey::Whiskey()
{

}

Whiskey::~Whiskey()
{

}

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks
#include "Fireball.h"

namespace Drinks {
namespace Liquor {
namespace Whiskey {

Fireball::Fireball()
{
    _drinkType = DRINK_TYPE_FIREBALL;
}

Fireball::~Fireball()
{

}

void Fireball::printDrinkReview()
{
    std::cout << "Fireball, love it or hate it.  My opinion changes constantly." << std::endl;
}

} //end namespace Whiskey
} //end namespace Liquor
} //end namespace Drinks
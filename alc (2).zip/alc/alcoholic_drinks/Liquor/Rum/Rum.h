#ifndef RUM_H__
#define RUM_H__

#include "../Liquor.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

class Rum : public Liquor
{
public:
Rum();
~Rum();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks

#endif //RUM_H__
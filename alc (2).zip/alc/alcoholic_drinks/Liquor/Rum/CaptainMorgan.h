#ifndef CAPTAIN_MORGAN_H__
#define CAPTAIN_MORGAN_H__

#include "Rum.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

class CaptainMorgan : public Rum
{
public:
CaptainMorgan();
~CaptainMorgan();
void printDrinkReview();

protected:

private:
};

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks

#endif //CAPTAIN_MORGAN_H__
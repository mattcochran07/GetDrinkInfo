#include "Rum.h"

namespace Drinks {
namespace Liquor {
namespace Rum {

Rum::Rum()
{

}

Rum::~Rum()
{

}

} //end namespace Rum
} //end namespace Liquor
} //end namespace Drinks
#include "IPA.h"

namespace Drinks {
namespace Beer {
namespace IPA {

IPA::IPA()
{

}

IPA::~IPA()
{

}

} //end namespace IPA
} //end namespace Beer
} //end namespace Drinks

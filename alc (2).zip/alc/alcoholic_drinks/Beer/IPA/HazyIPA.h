#ifndef HAZY_IPA_H__
#define HAZY_IPA_H__

#include <iostream>
#include <string>
#include "IPA.h"

namespace Drinks {
namespace Beer {
namespace IPA {

class HazyIPA : public IPA
{
public:
HazyIPA();
~HazyIPA();
void printDrinkReview();

private:
};

} //end namespace IPA
} //end namespace Beer
} //end namespace Drinks

#endif //HAZY_IPA_H__
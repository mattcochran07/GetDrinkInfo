#ifndef STOUT_H__
#define STOUT_H__

#include <iostream>
#include <string>
#include "../Beer.h"

namespace Drinks {
namespace Beer {
namespace Stout {

class Stout : public Beer
{
public:
Stout();
~Stout();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks



#endif //STOUT_H__
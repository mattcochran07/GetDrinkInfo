#include "Stout.h"

namespace Drinks {
namespace Beer {
namespace Stout {

Stout::Stout()
{

}

Stout::~Stout()
{

}

} //end namespace Stout
} //end namespace Beer
} //end namespace Drinks
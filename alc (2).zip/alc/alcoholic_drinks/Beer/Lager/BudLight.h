#ifndef BUDLIGHT_H__
#define BUDLIGHT_H__

#include <iostream>
#include <string>
#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

class BudLight : public Lager
{
public:
BudLight();
~BudLight();
void printDrinkReview();

private:
};

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#endif //BUDLIGHT_H__
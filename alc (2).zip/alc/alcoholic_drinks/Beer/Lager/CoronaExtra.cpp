#include "CoronaExtra.h"

namespace Drinks {
namespace Beer {
namespace Lager {

CoronaExtra::CoronaExtra()
{

}

CoronaExtra::~CoronaExtra()
{

}

void CoronaExtra::printDrinkReview()
{
    std::cout << "Corona is one of the best vacation beers.  With a lime... cant go wrong" << std::endl;
}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks
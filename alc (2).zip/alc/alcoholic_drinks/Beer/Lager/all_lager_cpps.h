#include "Lager.cpp"

#include "BudLight.cpp"
#include "CoorsLight.cpp"
#include "MichelobUltra.cpp"
#include "CoronaExtra.cpp"
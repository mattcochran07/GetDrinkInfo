#include "MichelobUltra.h"

namespace Drinks {
namespace Beer {
namespace Lager {

MichelobUltra::MichelobUltra()
{

}

MichelobUltra::~MichelobUltra()
{

}

void MichelobUltra::printDrinkReview()
{
    std::cout << "Michelob Ultra: If this things for women then im a woman" << std::endl;
}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks
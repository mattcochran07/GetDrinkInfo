#ifndef CORONA_EXTRA_H__
#define CORONA_EXTRA_H__

#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

class CoronaExtra : public Lager
{
public:
CoronaExtra();
~CoronaExtra();
void printDrinkReview();

protected:

private:
};

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#endif //CORONA_EXTRA_H__
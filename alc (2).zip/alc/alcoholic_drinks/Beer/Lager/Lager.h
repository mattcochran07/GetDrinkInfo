#ifndef LAGER_H__
#define LAGER_H__

#include "../Beer.h"
#include <iostream>
#include <string>

namespace Drinks {
namespace Beer {
namespace Lager {

class Lager : public Beer
{
public:
Lager();
~Lager();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#endif //LAGER_H__
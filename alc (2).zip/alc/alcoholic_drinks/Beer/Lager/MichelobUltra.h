#ifndef MICHELOB_ULTRA_H__
#define MICHELOB_ULTRA_H__

#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

class MichelobUltra : public Lager
{
public:
MichelobUltra();
~MichelobUltra();
void printDrinkReview();
};

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

#endif //MICHELOB_ULTRA_H__
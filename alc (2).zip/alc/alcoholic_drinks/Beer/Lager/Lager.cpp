#include "Lager.h"

namespace Drinks {
namespace Beer {
namespace Lager {

Lager::Lager()
{

}

Lager::~Lager()
{

}

} //end namespace Lager
} //end namespace Beer
} //end namespace Drinks

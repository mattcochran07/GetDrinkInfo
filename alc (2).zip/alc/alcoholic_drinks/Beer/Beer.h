#ifndef BEER_H__
#define BEER_H__

#include <iostream>
#include <string>
#include "../Drink.h"

namespace Drinks {
namespace Beer {

enum {
    BEER_TYPE_LAGER,
    BEER_TYPE_IPA,
    BEER_TYPE_STOUT,
};

class Beer : public Drink
{
public:
Beer();
~Beer();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Beer
} //end namespace Drinks

#endif //BEER_H__
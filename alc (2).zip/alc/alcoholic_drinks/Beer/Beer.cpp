#include "Beer.h"

namespace Drinks {
namespace Beer {

const float BEER_NUM_OUNCES = 12;

Beer::Beer()
{

}

Beer::~Beer()
{

}

} //end namespace Beer
} //end namespace Drinks
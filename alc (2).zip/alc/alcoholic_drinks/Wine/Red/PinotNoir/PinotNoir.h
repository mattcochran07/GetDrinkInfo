#ifndef PINOT_NOIR_H__
#define PINOT_NOIR_H__

#include "../Red.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace PinotNoir {

class PinotNoir : public Red
{
public:
PinotNoir();
~PinotNoir();
void printDrinkReview();

protected:

private:
};

} //end namespace PinotNoir
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //PINOT_NOIR_H__
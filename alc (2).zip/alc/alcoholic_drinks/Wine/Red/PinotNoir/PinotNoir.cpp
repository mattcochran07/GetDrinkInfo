#include "PinotNoir.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace PinotNoir {

PinotNoir::PinotNoir()
{
    _drinkType = DRINK_TYPE_PINOT_NOIR;
}

PinotNoir::~PinotNoir()
{

}

void PinotNoir::printDrinkReview()
{
    std::cout << "Pinot noir is the tried and true red" << std::endl;
}

} //end namespace PinotNoir
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
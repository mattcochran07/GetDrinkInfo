#include "Merlot.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace Merlot {

Merlot::Merlot()
{
    _drinkType = DRINK_TYPE_MERLOT;
}

Merlot::~Merlot()
{
    
}

void Merlot::printDrinkReview()
{
    std::cout << "Merlot is a sunday dinner fancy wine for sure" << std::endl;
}

} //end namespace Merlot
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
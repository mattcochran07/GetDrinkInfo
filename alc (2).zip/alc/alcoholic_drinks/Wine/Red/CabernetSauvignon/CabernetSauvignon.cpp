#include "CabernetSauvignon.h"

namespace Drinks {
namespace Wine {
namespace Red {
namespace CabernetSauvignon {

CabernetSauvignon::CabernetSauvignon()
{
    _drinkType = DRINK_TYPE_CABERNET_SAUVIGNON;
}

CabernetSauvignon::~CabernetSauvignon()
{

}

void CabernetSauvignon::printDrinkReview()
{
    std::cout << "Cabernet Sauvignon is some fancy ppl shit" << std::endl;
}

} //end namespace CabernetSauvignon
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
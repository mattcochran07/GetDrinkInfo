#include "Red.h"

namespace Drinks {
namespace Wine {
namespace Red {

Red::Red()
{

}

Red::~Red()
{

}

} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
#ifndef RED_H__
#define RED_H__

#include "../Wine.h"

namespace Drinks {
namespace Wine {
namespace Red {

class Red : public Wine
{
public:
Red();
~Red();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //RED_H__
#include "Red.cpp"

#include "CabernetSauvignon/all_cabernet_sauvignon_cpps.h"
#include "Merlot/all_merlot_cpps.h"
#include "PinotNoir/all_pinot_noir_cpps.h"
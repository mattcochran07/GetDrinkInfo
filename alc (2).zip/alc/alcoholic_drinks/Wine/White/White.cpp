#include "White.h"

namespace Drinks {
namespace Wine {
namespace White {

White::White()
{

}

White::~White()
{

}

} //end namespace White
} //end namespace Wine
} //end namespace Drinks
#ifndef CHARDONNAY_H__
#define CHARDONNAY_H__

#include "../White.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace Chardonnay {

class Chardonnay : public White
{
public:
Chardonnay();
~Chardonnay();
void printDrinkReview();

protected:

private:
};

} //end namespace Chardonnay
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //CHARDONNAY_H__
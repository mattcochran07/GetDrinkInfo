#ifndef WHITE_H__
#define WHITE_H__

#include "../Wine.h"

namespace Drinks {
namespace Wine {
namespace White {

class White : public Wine
{
public:
White();
~White();

protected:
virtual void printDrinkReview() = 0;

private:
};

} //end namespace White
} //end namespace Wine
} //end namespace Drinks

#endif //WHITE_H__
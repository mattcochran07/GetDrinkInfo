#include "SauvignonBlanc.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace SauvignonBlanc {

SauvignonBlanc::SauvignonBlanc()
{
    _drinkType = DRINK_TYPE_SAUVIGNON_BLANC;
}

SauvignonBlanc::~SauvignonBlanc()
{
    
}

void SauvignonBlanc::printDrinkReview()
{
    std::cout << "This is the only white wine I can stand" << std::endl;
}

} //end namespace SauvignonBlanc
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks
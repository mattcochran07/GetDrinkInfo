#ifndef PINOT_GRIGIO_H__
#define PINOT_GRIGIO_H__

#include "../White.h"

namespace Drinks {
namespace Wine {
namespace White {
namespace PinotGrigio {

class PinotGrigio : public White
{
public:
PinotGrigio();
~PinotGrigio();
void printDrinkReview();

protected:

private:
};

} //end namespace PinotGrigio
} //end namespace Red
} //end namespace Wine
} //end namespace Drinks

#endif //PINOT_GRIGIO_H__
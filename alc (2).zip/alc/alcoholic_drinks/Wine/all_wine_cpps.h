#include "Wine.cpp"

#include "Red/all_red_cpps.h"
#include "White/all_white_cpps.h"
#include "Rose/all_rose_cpps.h"
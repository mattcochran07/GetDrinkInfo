#ifndef WINE_H__
#define WINE_H__

#include "../Drink.h"
#include <iostream>
#include <string>

namespace Drinks {
namespace Wine {

class Wine : public Drink
{
public:
Wine();
~Wine();

protected:
virtual void printDrinkReview() = 0;

private:
};

}
}


#endif //WINE_H__
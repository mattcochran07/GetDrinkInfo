#include "Wine.h"

namespace Drinks {
namespace Wine {

const float WINE_NUM_OUNCES = 5;

Wine::Wine()
{

}

Wine::~Wine()
{

}

} //end namespace Wine
} //end namespace Drinks
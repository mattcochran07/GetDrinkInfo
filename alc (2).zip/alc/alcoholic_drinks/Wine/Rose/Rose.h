#ifndef ROSE_H__
#define ROSE_H__

#include "../Wine.h"

namespace Drinks {
namespace Wine {
namespace Rose {

class Rose : public Wine
{
public:
Rose();
~Rose();
void printDrinkReview();

protected:

private:
};

} //end namespace Rose
} //end namespace Wine
} //end namespace Drinks

#endif //ROSE_H__
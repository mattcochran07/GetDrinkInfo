#include "Rose.h"

namespace Drinks {
namespace Wine {
namespace Rose {

Rose::Rose()
{
    _drinkType = DRINK_TYPE_ROSE;
}

Rose::~Rose()
{

}

void Rose::printDrinkReview()
{
    std::cout << "There was little effort put into the Rose section are you surprised" << std::endl;
}

} //end namespace Rose
} //end namespace Wine
} //end namespace Drinks
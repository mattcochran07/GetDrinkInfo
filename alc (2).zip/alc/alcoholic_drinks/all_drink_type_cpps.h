#include "Beer/all_beer_cpps.h"
#include "Wine/all_wine_cpps.h"
#include "Liquor/all_liquor_cpps.h"

#include "UnhandledDrink.cpp"
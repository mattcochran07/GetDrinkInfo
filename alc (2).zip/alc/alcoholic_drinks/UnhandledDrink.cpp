#include "UnhandledDrink.h"

namespace Drinks {

UnhandledDrink::UnhandledDrink()
{

}

UnhandledDrink::~UnhandledDrink()
{

}

void UnhandledDrink::printDrinkReview()
{
    std::cout << "ERROR!!!  This is an unrecognized drink.  Im sorry but I cant make this" << std::endl;
}

} //end namespace Drinks
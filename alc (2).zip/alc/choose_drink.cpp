#include "common_includes.h"
#include "all_cpp_files.h"

void parseCommandLineArguments(int argc, char** argv, std::string* selected)
{
    //Only doing 1 command line argument right now so it will be the last item in the list
    *selected = std::string(argv[argc-1]);
}

int main(int argc, char** argv)
{
    std::string line;
    std::vector<std::string> lines;
    std::ifstream file;

    bool tf_debug = false;
    //read parameters file
    file.open("txt_files/run_parameters.xml");
    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            if (line.find("<debug>") != std::string::npos)
            {
                std::stringstream ss;
                std::string dbg = "<debug>";
                char num = line[dbg.size()];
                ss << num;
                int tf;
                ss >> tf;
                if (tf)
                {
                    tf_debug = true;
                }
            }
        }
    }
    file.close();

    //parse command line to find out which string to print
    std::string drinkToDisplay;
    parseCommandLineArguments(argc, argv, &drinkToDisplay);

    Drinks::DrinkFactory drinkFactory;

    Drinks::Drink* bev = drinkFactory.getDrink(drinkToDisplay);
    std::cout << std::endl << "Matthews Drink Review of " << drinkToDisplay << ":" << std::endl;
    bev->printDrinkReview();
    return 0;
}